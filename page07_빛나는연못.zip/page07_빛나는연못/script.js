"use strict";
// 사주 AI 풀이 페이지 스크립트 (TypeScript)
// 정적 콘텐츠 위주라 로직은 단순하지만, 추후 기능(페이지 전환 애니메이션,
// 실제 사주 데이터 바인딩 등)을 추가할 때 타입 안전하게 확장할 수 있도록
// TypeScript로 작성했습니다.
/**
 * .meter i 요소들의 width를 0%에서 목표값까지 부드럽게 애니메이션합니다.
 * 목표값은 인라인 style="width:NN%"에 이미 설정되어 있다고 가정합니다.
 */
function animateMeters(root = document) {
    const bars = root.querySelectorAll(".meter i");
    bars.forEach((bar) => {
        const target = bar.style.width || "0%";
        bar.style.width = "0%";
        requestAnimationFrame(() => {
            bar.style.transition = "width 900ms ease";
            bar.style.width = target;
        });
    });
}
document.addEventListener("DOMContentLoaded", () => {
    animateMeters(document);
});
//# sourceMappingURL=script.js.map