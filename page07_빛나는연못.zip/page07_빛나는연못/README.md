# 스크립트 수정 안내 (TypeScript)

이 폴더의 `script.js`는 `script.ts`를 컴파일해서 만든 결과물입니다.
브라우저는 `.ts` 파일을 직접 실행할 수 없기 때문에, `index.html`은 항상
컴파일된 `script.js`를 불러옵니다.

## 코드를 수정하려면

1. `script.ts`를 원하는 대로 수정합니다.
2. 아래 명령으로 다시 컴파일합니다. (최초 1회 `npm install -g typescript` 필요)

   npx tsc -p tsconfig.json

3. `script.js`(및 `script.js.map`)가 새로 생성되면 `index.html`을 새로고침해서 확인합니다.

`script.js`를 직접 고쳐도 동작은 하지만, 다음 컴파일 때 덮어써지니
가능하면 `script.ts`에서 수정하는 것을 권장합니다.
