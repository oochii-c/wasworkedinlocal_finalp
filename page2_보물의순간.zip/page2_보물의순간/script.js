// 사주 AI 풀이 페이지 스크립트
// 현재는 정적 콘텐츠라 별도 동작이 없지만,
// 추후 점수 애니메이션, 페이지 전환 등을 추가할 자리로 비워둡니다.

document.addEventListener("DOMContentLoaded", () => {
  // meter 바가 부드럽게 채워지는 간단한 연출
  document.querySelectorAll(".meter i").forEach((bar) => {
    const target = bar.style.width;
    bar.style.width = "0%";
    requestAnimationFrame(() => {
      bar.style.transition = "width 900ms ease";
      bar.style.width = target;
    });
  });
});
