"""
컴포넌트(남색-골드 테두리 박스) + 글씨를 "그라데이션 (이전 버전, 488x1872)" 배경에 합성하는 스크립트

배경 파일   : bg_target2.png
컴포넌트1   : component_frame.png   (장식 있는 버전, 아래쪽 박스)
컴포넌트2   : component_frame2.png  (단순 버전, 위쪽 박스)
출력 파일   : text_02_gradient_v1.png

컴포넌트 가로 폭 : 400px
컴포넌트1 위치   : x=44, y=690   (텍스트: "일일 미션")
컴포넌트2 위치   : x=44, y=589   (텍스트: "보상 받기")

필요 패키지: pillow, numpy, scipy
    pip install pillow numpy scipy
필요 폰트: 한글 트루타입 폰트 (예시는 Noto Sans CJK 경로 사용, 환경에 맞게 FONT_PATH 수정)
"""

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage


def make_white_bg_transparent(png_path, white_threshold=235):
    img = Image.open(png_path).convert("RGB")
    arr = np.array(img)
    white_mask = (
        (arr[:, :, 0] > white_threshold)
        & (arr[:, :, 1] > white_threshold)
        & (arr[:, :, 2] > white_threshold)
    )
    labeled, _ = ndimage.label(white_mask, structure=np.ones((3, 3)))
    border_labels = set()
    border_labels.update(labeled[0, :].tolist())
    border_labels.update(labeled[-1, :].tolist())
    border_labels.update(labeled[:, 0].tolist())
    border_labels.update(labeled[:, -1].tolist())
    border_labels.discard(0)
    transparent_mask = np.isin(labeled, list(border_labels))
    alpha = np.where(transparent_mask, 0, 255).astype("uint8")
    return Image.fromarray(np.dstack([arr, alpha]), "RGBA")


def fit_to_width(frame, target_w):
    fw, fh = frame.size
    scale = target_w / fw
    return frame.resize((target_w, round(fh * scale)), Image.LANCZOS)


def draw_centered_text(canvas, box_xy, box_size, text, font_path, font_size, fill, font_index=1, stroke_width=0, stroke_fill=None):
    if not text:
        return
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.truetype(font_path, font_size, index=font_index)
    x, y = box_xy
    w, h = box_size
    bbox = draw.textbbox((0, 0), text, font=font, stroke_width=stroke_width)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    tx = x + (w - tw) / 2 - bbox[0]
    ty = y + (h - th) / 2 - bbox[1]
    draw.text((tx, ty), text, font=font, fill=fill, stroke_width=stroke_width, stroke_fill=stroke_fill)


if __name__ == "__main__":
    BACKGROUND = "bg_target2.png"
    COMPONENT_1 = "component_frame.png"
    COMPONENT_2 = "component_frame2.png"

    target_width = 400
    x = 44
    y1 = 690
    y2 = 589

    # ↓↓↓ 원하는 문구로 바꾸세요. 비우면("") 글씨 없이 박스만 나옵니다.
    TEXT_1 = "일일 미션"   # y1 위치(장식 버전) 박스 안 문구
    TEXT_2 = "보상 받기"   # y2 위치(단순 버전) 박스 안 문구

    FONT_PATH = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
    FONT_INDEX = 1  # Noto Sans CJK KR (0=JP, 1=KR, 2=SC, 3=TC, 4=HK)
    FONT_SIZE = 30
    TEXT_COLOR_1 = (255, 255, 255, 255)   # 흰색
    TEXT_COLOR_2 = (255, 230, 170, 255)   # 연한 골드

    bg = Image.open(BACKGROUND).convert("RGBA")
    c1 = fit_to_width(make_white_bg_transparent(COMPONENT_1), target_width)
    c2 = fit_to_width(make_white_bg_transparent(COMPONENT_2), target_width)

    composite = bg.copy()
    composite.alpha_composite(c2, (x, y2))
    composite.alpha_composite(c1, (x, y1))

    draw_centered_text(composite, (x, y1), c1.size, TEXT_1, FONT_PATH, FONT_SIZE, TEXT_COLOR_1, FONT_INDEX)
    draw_centered_text(composite, (x, y2), c2.size, TEXT_2, FONT_PATH, FONT_SIZE, TEXT_COLOR_2, FONT_INDEX)

    composite.convert("RGB").save("text_02_gradient_v1.png")
    print("done -> text_02_gradient_v1.png")
