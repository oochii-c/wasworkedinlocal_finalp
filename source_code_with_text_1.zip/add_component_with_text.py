"""
컴포넌트(남색-골드 테두리 박스)를 배경에 합성하면서, 박스 안에 글씨(텍스트)도
가운데 정렬로 함께 그려주는 스크립트.

기존 add_component.py 에 텍스트 렌더링 기능만 추가한 버전입니다.
아래 TEXT_1 / TEXT_2 값을 원하는 문구로 바꾸면 됩니다. (비워두면 글씨 없이 박스만 합성)

필요 패키지: pillow, numpy, scipy
    pip install pillow numpy scipy

필요 폰트: 한글이 포함된 트루타입 폰트 (예: Noto Sans CJK KR)
    이 예제는 리눅스 환경 기준 Noto Sans CJK 경로를 사용합니다.
    다른 환경에서는 FONT_PATH를 시스템에 있는 한글 폰트 경로로 바꿔주세요.
    (Windows 예: "C:/Windows/Fonts/malgun.ttf", index 필요 없음)
"""

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage


def make_white_bg_transparent(png_path, white_threshold=235):
    """컴포넌트 PNG의 흰색 배경(테두리 바깥쪽)만 투명 처리해서 RGBA 이미지로 반환한다.
    내부 장식(흰 선 등)은 캔버스 가장자리와 연결되어 있지 않으므로 보존된다."""
    img = Image.open(png_path).convert("RGB")
    arr = np.array(img)

    white_mask = (
        (arr[:, :, 0] > white_threshold)
        & (arr[:, :, 1] > white_threshold)
        & (arr[:, :, 2] > white_threshold)
    )

    labeled, _ = ndimage.label(white_mask, structure=np.ones((3, 3)))

    border_labels = set()
    border_labels.update(labeled[0, :].tolist())
    border_labels.update(labeled[-1, :].tolist())
    border_labels.update(labeled[:, 0].tolist())
    border_labels.update(labeled[:, -1].tolist())
    border_labels.discard(0)

    transparent_mask = np.isin(labeled, list(border_labels))
    alpha = np.where(transparent_mask, 0, 255).astype("uint8")

    rgba = np.dstack([arr, alpha])
    return Image.fromarray(rgba, "RGBA")


def fit_to_width(frame, target_w):
    """가로 폭을 target_w에 맞춰 비율 유지한 채 리사이즈한다."""
    fw, fh = frame.size
    scale = target_w / fw
    target_h = round(fh * scale)
    return frame.resize((target_w, target_h), Image.LANCZOS)


def draw_centered_text(
    canvas,
    box_xy,
    box_size,
    text,
    font_path,
    font_size,
    fill=(255, 255, 255, 255),
    font_index=0,
    stroke_width=0,
    stroke_fill=None,
):
    """canvas 위, (box_xy, box_size)로 정의된 사각형 한가운데에 text를 그린다."""
    if not text:
        return
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.truetype(font_path, font_size, index=font_index)
    x, y = box_xy
    w, h = box_size
    bbox = draw.textbbox((0, 0), text, font=font, stroke_width=stroke_width)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    tx = x + (w - tw) / 2 - bbox[0]
    ty = y + (h - th) / 2 - bbox[1]
    draw.text(
        (tx, ty), text, font=font, fill=fill, stroke_width=stroke_width, stroke_fill=stroke_fill
    )


if __name__ == "__main__":
    BACKGROUND = "background.png"
    COMPONENT_1 = "component_frame.png"   # 장식 있는 버전
    COMPONENT_2 = "component_frame2.png"  # 단순 버전

    target_width = 260
    x = 590
    y1 = 450   # 컴포넌트1 (장식 버전) 위치
    y2 = 349   # 컴포넌트2 (단순 버전) 위치, 컴포넌트1보다 위쪽

    # ↓↓↓ 여기 문구를 원하는 대로 바꾸세요. 비우면("") 텍스트 없이 박스만 나옵니다.
    TEXT_1 = "일일 미션"
    TEXT_2 = "보상 받기"

    FONT_PATH = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
    FONT_INDEX = 1  # Noto Sans CJK KR (0=JP, 1=KR, 2=SC, 3=TC, 4=HK)
    FONT_SIZE = 26
    TEXT_COLOR_1 = (255, 255, 255, 255)      # 흰색
    TEXT_COLOR_2 = (255, 230, 170, 255)      # 연한 골드

    bg = Image.open(BACKGROUND).convert("RGBA")

    c1 = fit_to_width(make_white_bg_transparent(COMPONENT_1), target_width)
    c2 = fit_to_width(make_white_bg_transparent(COMPONENT_2), target_width)

    composite = bg.copy()
    composite.alpha_composite(c2, (x, y2))
    composite.alpha_composite(c1, (x, y1))

    draw_centered_text(composite, (x, y1), c1.size, TEXT_1, FONT_PATH, FONT_SIZE, TEXT_COLOR_1, FONT_INDEX)
    draw_centered_text(composite, (x, y2), c2.size, TEXT_2, FONT_PATH, FONT_SIZE, TEXT_COLOR_2, FONT_INDEX)

    composite.convert("RGB").save("composited_result_with_text.png")
    print("done -> composited_result_with_text.png")
